import axios from 'axios';
class BookDataService {

  async create(data) {
    await axios.post("http://localhost:8081/create", data, { withCredentials: true })
      .then(async res => {
        let x = await res.data

        if (x.status === true) {
          alert(x.status);
        }
        else {
          alert(x.message)
        }
      })
      .catch(error => {
        alert(error);
      })
  }

  async getBooks(){

  }

  async delete(data) {
  }
}

export default new BookDataService();