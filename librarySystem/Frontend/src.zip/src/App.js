import './App.css';
import BookList from './Components/BookList';
import { BrowserRouter, Route, Routes } from "react-router-dom";
import AddBook from './Components/AddBook';
import Navbar from './Components/Navbar';
import AddUser from './Components/AddUser';
import UsersList from './Components/UsersList';
import LoginPage from './Components/LoginPage';
function App() {
  return (
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<LoginPage/>}></Route>
          <Route path='/Books' element={<BookList/>}></Route>
          <Route path='/AddBook' element={<AddBook title = "Add Book"/>}></Route>
          <Route path='/AddBook/:id' element={<AddBook title = "Update Book"/>}></Route>
          <Route  path='/Users' element = {<UsersList/>}></Route>
          <Route path='/AddUser' element = {<AddUser title = "Add User"/>}></Route>
          <Route path='/AddUser/:id' element = {<AddUser title = "Update User"/>}></Route>
        </Routes>
      </BrowserRouter>
  );
}

export default App;
