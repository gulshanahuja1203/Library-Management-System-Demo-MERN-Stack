import React, { Component } from 'react'
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import { Grid, TextField, Button } from '@mui/material';
import Paper from '@mui/material/Paper';
import '../LoginPage.css'
import axios from 'axios';
import Box from '@mui/material/Box';
import Snackbar from '@mui/material/Snackbar';
import { Stack } from '@mui/material';
import { Alert } from '@mui/material';
import withRouter from '../withRouter';
import { Typography } from '@mui/material'
class LoginPage extends Component {
    // componentDidMount() {
    //     setHeaderToken();
    // }
    constructor() {
        super();
        this.state = {
            Email: "",
            Password: "",
            open: false,
            severity: "error",
            message: ""
        }
    }
    setField = (event) => {
        this.setState({ [event.target.name]: event.target.value });
    }
    loginUser = () => {
        debugger;
        sessionStorage.clear();
        const userData = {
            Email: this.state.Email,
            Password: this.state.Password
        }
        console.log(userData);
        axios.post('/loginUser', userData, { withCredentials: true })
            .then(response => {
                console.log(response);
                if (response.data.status) {
                    this.setState({ message: response.data.message, severity: "success", open: true });
                    console.log("authToken is : ", response.data.token);
                    sessionStorage.setItem("User", JSON.stringify(response.data));
                    this.props.navigate('/Books');
                }
                else {
                    this.setState({ message: response.data.message, severity: "error", open: true });
                    // this.props.navigate('/Books');
                }
            })
            .catch(error => {
                this.setState({ message: error });
                this.setState({ message: error.data.message, severity: "error", open: true });
            })
    }
    handleClose = () => {
        this.setState({ open: false });
    }
    render() {
        return (
            <>
                <Stack spacing={2} sx={{ width: '100%' }}>
                    <Snackbar
                    anchorOrigin={{ vertical: "top", horizontal: "center" }}
                    open={this.state.open} autoHideDuration={3000} onClose={this.handleClose}>
                        <Alert severity={this.state.severity} sx={{ width: '100%' }} onClose={this.handleClose}>
                            {this.state.message}
                        </Alert>
                    </Snackbar>
                </Stack>

                <Grid sx={{ marginY: "5%" }}>
                    <Card component={Paper} elevation={3} sx={{minWidth: "250px", display: 'flex', width: "25%", marginX: "auto" }}>
                        <Box sx={{ width: "100%" }}>
                            <Grid sx={{backgroundColor: "#4f0073"}}>
                                <Typography variant='h4' sx={{color: "white", marginX: "5%", padding: "3%"}}>
                                    Login
                                </Typography>
                            </Grid>
                            <br />
                            <CardContent sx={{ float: "center", padding: "5%" }}>
                                <AccountCircleIcon sx={{ width: "100%" }} fontSize='large'></AccountCircleIcon>
                                <Grid sx={{ width: "100%", marginY: "4%" }}>
                                    <TextField onChange={(event) => this.setField(event)} sx={{ width: "100%", marginTop: "1%", backgroundColor: "white" }} id="Email" name='Email' label="Email" variant="filled" color='secondary' />
                                </Grid>
                                <Grid sx={{ width: "100%", marginY: "4%" }}>
                                    <TextField type='Password' onChange={(event) => this.setField(event)} sx={{ width: "100%", marginTop: "1%", marginY: "3%", backgroundColor: "white" }} id="Password" name='Password' label="Password" variant="filled" color='secondary' />
                                </Grid>
                                <Grid sx={{ width: "100%", marginY: "4%", marginBottom: "25%" }}>
                                    <Button onClick={this.loginUser} sx={{ width: "100%", float: "right", color: "white", fontweight: "bold"}} variant="contained" color='secondary'>
                                        Login
                                    </Button>
                                </Grid>
                            </CardContent>
                        </Box>
                    </Card>
                </Grid>
            </>
        )
    }
}
export default withRouter(LoginPage)