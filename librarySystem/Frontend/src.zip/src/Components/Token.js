import axios from "axios";
let userData = null;
let Token = null;
const setHeaderToken = () => {
    console.log("sessionStorage ", sessionStorage.getItem("User"));
    console.log("User data before json.parse ", userData);
    userData = JSON.parse(sessionStorage.getItem("User"));
    console.log("User data after json.parse ", userData);
    console.log("Token before ", Token);
    if (userData) {
        Token = userData.token;
        console.log("Token after ", Token);
        console.log("Token is ", Token);
        axios.defaults.headers.common['Authorization'] = `Bearer ${Token}`;
        axios.defaults.headers.post['Content-Type'] = 'application/json';
    }
    else {
        axios.defaults.headers.common['Authorization'] = null;
        // axios.defaults.headers.post['Content-Type'] = null;
    }
}

export default setHeaderToken;