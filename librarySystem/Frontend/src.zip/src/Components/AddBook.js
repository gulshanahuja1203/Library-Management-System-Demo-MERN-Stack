import React, { Component } from 'react'
import Typography from '@mui/material/Typography';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import { Link } from 'react-router-dom';
import Checkbox from '@mui/material/Checkbox';
import axios from 'axios';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import withRouter from '../withRouter';
import Grid from '@mui/material/Grid';
import FormHelperText from '@mui/material/FormHelperText';
import setHeaderToken from './Token';
import Navbar from './Navbar';
import { Stack, Snackbar, Alert } from '@mui/material';
//=================== Class AddBook
class AddBook extends Component {

    componentDidMount() {
        setHeaderToken();
        this.getCategoryList();
        this.getPublisherList();
        if (this.props.params.id) {
            this.getDataById();
        }
    }

    //===================Constructor
    constructor(props) {
        super(props);
        this.state = {
            categoryList: [],
            publisherList: [],
            BookId: this.props.params.id,
            BookName: "",
            CategoryName: "",
            check: false,
            PublisherName: "",
            BookNameError: "",
            CategoryId: "",
            PublisherId: "",
            open: false,
            severity: "error",
            message: ""
        }
    }

    delay = ms => new Promise(
        resolve => setTimeout(resolve, ms)
    );

    //===================== Set The Field On Change In Values
    setField = (event) => {
        this.setState({ [event.target.name]: event.target.value });
    }

    //===================== Set The Check Field On Change
    setCheckField = (event) => {
        this.setState({ [event.target.name]: event.target.checked })
    }

    //===================== Validate The Form
    validation = () => {
        if (this.state.BookName === "" || !this.state.BookName.length) {
            this.setState({ BookNameError: "Book Name is Invalid" });
            return false;
        }
        else {
            this.setState({ BookNameError: "" });
        }

        if (this.state.CategoryName === "" || this.state.CategoryName === "None" || !this.state.CategoryName.length) {
            return false;
        }

        if (this.state.PublisherName === "" || !this.state.PublisherName.length) {
            return false;
        }
        return true;

    }

    //======================== Insert A New Book
    saveData = (event) => {

        if (this.validation()) {
            if (this.state.BookId) {
                this.updateBook();
            }
            else {
                var data = {
                    BookName: this.state.BookName,
                    check: this.state.check,
                    PublisherId: this.state.PublisherName,
                    CategoryId: this.state.CategoryName,
                };
                axios.post("http://localhost:8081/create", data, { withCredentials: true })
                    .then(async res => {
                        let x = await res.data

                        if (x.status === true) {
                            this.setState({ message: res.data.message, severity: "success", open: true }, () => {
                                this.props.navigate('/Books');
                            });
                        }
                        else {
                            this.setState({ message: res.data.message, severity: "error", open: true });
                        }
                    })
                    .catch(error => {
                        this.setState({ message: error.response.data.message, severity: "error", open: true }, async () => {
                            await this.delay(3000);
                            sessionStorage.clear();
                            this.props.navigate('/')
                        });
                        console.log(error.response);
                        console.log(error);
                    })
            }
        }
    };

    //==================== To Get The Book Id To Edit
    getDataById = async () => {
        if (this.state.BookId !== "") {
            await axios.get(`http://localhost:8081/getBook/${this.state.BookId}`, { withCredentials: true })
                .then(response => {
                    console.log(response);
                    this.setState({ BookName: response.data.data.BookName });
                    this.setState({ CategoryName: response.data.data.CategoryId });
                    this.setState({ PublisherName: response.data.data.PublisherId });
                    this.setState({ check: response.data.data.IsActive });
                })
                .catch(error => {
                    this.setState({ message: error.response.data.message, severity: "error", open: true }, async () => {
                        await this.delay(3000);
                        this.props.navigate('/Books')
                    });
                    console.log(error.response);
                    console.log(error);
                    // alert(error.status + " " + error.response.data.message);
                })
        }
        else {
            this.setState = {
                BookId: "",
                BookName: "",
                CategoryName: "",
                PublisherName: "",
                check: false,
                BookNameError: "",
            }
        }
    }

    //========================== To Edit the Book
    updateBook = async () => {
        var data = {
            BookId: this.state.BookId,
            BookName: this.state.BookName,
            check: this.state.check,
            CategoryId: this.state.CategoryName,
            PublisherId: this.state.PublisherName,
        }
        await axios.post('/updateBook', data, { withCredentials: true })
            .then(response => {
                debugger;
                if (response.data.status) {
                    this.setState({ message: response.data.message, severity: "success", open: true }, async () => {
                        await this.delay(3000);
                        this.props.navigate('/Books');
                    })
                }
            })
            .catch(error => {
                debugger;
                // alert(error.status + " " + error.response.data.message);
                this.setState({ message: error.response.data.message, severity: "error", open: true }, async () => {
                    await this.delay(3000);
                    sessionStorage.clear();
                    this.props.navigate('/Books');
                })
            })
    }

    //========================== Get The List Of Categories
    getCategoryList = async () => {
        await axios.get('/category/display')
            .then(response => {
                this.setState({ categoryList: response.data.data });
            }, [])
            .catch(error => {
                // alert(error.status + " " + error.response.data.message);
                this.setState({ message: error.response.data.message, severity: "error", open: true }, async () => {
                    await this.delay(3000);
                    sessionStorage.clear();
                    this.props.navigate('/');
                })
            })
    }

    //========================== Get The List Of Publishers
    getPublisherList = async () => {
        await axios.get('/publisher/display')
            .then(response => {
                this.setState({ publisherList: response.data.data });
            }, [])
            .catch(error => {
                // alert(error.status + " " + error.response.data.message);
                this.setState({ message: error.response.data.message, severity: "error", open: true }, async () => {
                    await this.delay(3000);
                    sessionStorage.clear();
                    this.props.navigate('/');
                })
            })
    }

    getCategoryById = async (id) => {
        await axios.get(`/getCategory/${id}`)
            .then(response => {
                return response.data.data.CategoryName;
            })
            .catch(error => {
                // alert(error.status + " " + error.response.data.message);
                this.setState({ message: error.response.data.message, severity: "error", open: true }, async () => {
                    await this.delay(3000);
                    sessionStorage.clear();
                    this.props.navigate('/');
                })
            })
    }

    getPublisherById = async (id) => {
        await axios.get(`/getPublisher/${id}`)
            .then(response => {
                return response.data.data.PublisherName;
            })
            .catch(error => {
                // alert(error.status + " " + error.response.data.message);
                this.setState({ message: error.response.data.message, severity: "error", open: true }, async () => {
                    await this.delay(3000);
                    sessionStorage.clear();
                    this.props.navigate('/');
                })
            })
    }

    handleClose = () => {
        this.setState({ open: false });
    }

    //======================== Start Page
    render() {
        const { categoryList } = this.state, { publisherList } = this.state;
        return (
            <>
                <Navbar />
                <Stack spacing={2} sx={{ width: '100%' }}>
                    <Snackbar
                        anchorOrigin={{ vertical: "top", horizontal: "center" }}
                        open={this.state.open} autoHideDuration={3000} onClose={this.handleClose}>
                        <Alert severity={this.state.severity} sx={{ width: '100%' }} onClose={this.handleClose}>
                            {this.state.message}
                        </Alert>
                    </Snackbar>
                </Stack>
                <Grid container spacing={2} item sm={12}
                    sx={{
                        display: 'flex',
                        flexWrap: 'wrap',
                        marginX: "auto",
                        marginY: "100px",
                        fontFamily: "Times New Roman",
                        paddingTop: "20px",
                        width: "40%",
                        minWidth: "300px"
                    }
                    }>

                    <Grid container>
                        <Card
                            variant='outlined'
                            sx={{
                                width: "100%",
                                marginY: "1%",
                                marginX: "auto",
                                borderRadius: "20px",
                                padding: "2%",
                                height: "auto"
                            }}>
                            <CardContent>
                                <Grid>
                                    <Typography
                                        variant='h4'
                                        sx={{
                                            marginX: "8%",
                                            marginY: "auto",
                                            fontWeight: "bold",
                                            color: "black"
                                        }}>
                                        {this.props.title}
                                        <hr />
                                    </Typography>
                                </Grid>
                                <Grid>
                                    <TextField
                                        error={this.state.BookNameError && this.state.BookNameError.length ? true : false}
                                        sx={{
                                            float: "center",
                                            marginTop: "5%",
                                            width: "100%"
                                        }}
                                        id="BookName"
                                        name='BookName'
                                        label="Book Name"
                                        variant="filled"
                                        value={this.state.BookName}
                                        onChange={(event) => this.setField(event)}
                                        helperText={this.state.BookNameError}
                                    />
                                </Grid>
                                <Grid>
                                    <FormControl variant='filled'
                                        error={this.state.CategoryName === "" ? true : false}
                                        sx={{ marginTop: "5%", width: "100%" }}
                                    >
                                        <InputLabel id="CategoryName">Categories</InputLabel>
                                        {this.state.categoryList &&
                                            <Select required
                                                labelId="CategoryName"
                                                id="CategoryName"
                                                name='CategoryName'
                                                value={this.state.CategoryName}
                                                label="CategoryName"
                                                onChange={(event) => this.setField(event)}
                                            >
                                                <MenuItem value=""><em>None</em></MenuItem>
                                                {categoryList && categoryList.map((row) => {
                                                    return (
                                                        <MenuItem key={row._id} value={row._id}>{row.CategoryName}</MenuItem>
                                                    )
                                                })};
                                            </Select>
                                        }
                                        <FormHelperText>Select A Category Name</FormHelperText>
                                    </FormControl>
                                </Grid>

                                <Grid>
                                    <FormControl variant='filled'
                                        error={this.state.PublisherName === "" ? true : false}
                                        sx={{ marginTop: "5%", width: "100%" }}
                                        helperText="Publisher Name is Invalid"
                                    >
                                        <InputLabel id="Publishers">Publishers</InputLabel>
                                        {this.state.publisherList &&
                                            <Select
                                                labelId="Publishers"
                                                id="PublisherName"
                                                name='PublisherName'
                                                value={this.state.PublisherName}
                                                label="Publisher"
                                                onChange={(event) => this.setField(event)}
                                            >
                                                <MenuItem value=""><em>None</em></MenuItem>
                                                {publisherList && publisherList.map((row) => {
                                                    return (
                                                        <MenuItem key={row._id} value={row._id}>{row.PublisherName}</MenuItem>
                                                    )
                                                })};
                                            </Select>
                                        }
                                        <FormHelperText>Select A Publisher Name</FormHelperText>
                                    </FormControl>
                                </Grid>


                                <Grid sx={{ marginTop: "25px", border: "1px solid #E0E0E0", paddingY: "2px", paddingLeft: "5px" }}>
                                    <FormControl variant='filled'>
                                        <Typography variant='span' sx={{ fontSize: "15px", fontWeight: "bold", color: "E0E0E" }}>Status</Typography>
                                        <Checkbox checked={this.state.check} id='check' name='check' onChange={(event) => this.setCheckField(event)} />
                                    </FormControl>
                                </Grid>
                            </CardContent>
                        </Card>
                        <Grid sx={{ marginLeft: "auto", marginRight: "20px" }}>
                            <Button variant="contained" onClick={(event) => this.saveData(event)} sx={{ margin: "10px" }}>Save Book</Button>
                            <Link to='/Books'><Button variant="contained" sx={{ margin: "10px" }}>Cancel</Button></Link>
                        </Grid>
                    </Grid>
                </Grid >
            </>
        )
    }
}
export default withRouter(AddBook);