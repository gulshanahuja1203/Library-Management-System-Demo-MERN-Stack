import React, { Component } from 'react'
import Typography from '@mui/material/Typography';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import { Link } from 'react-router-dom';
import Checkbox from '@mui/material/Checkbox';
import axios from 'axios';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import withRouter from '../withRouter';
import Grid from '@mui/material/Grid';
import FormHelperText from '@mui/material/FormHelperText';
import setHeaderToken from './Token';
import Navbar from './Navbar';
import { Stack, Snackbar, Alert } from '@mui/material';
//=================== Class AddBook
class AddBook extends Component {

    componentDidMount() {
        setHeaderToken();
        this.getRoles();
        if (this.props.params.id) {
            this.getUserById();
        }
    }

    //===================Constructor
    constructor(props) {
        super(props);
        this.state = {
            UserList: [],
            UserId: this.props.params.id,
            check: false,
            FirstName: "",
            LastName: "",
            Password: "",
            ConfirmPassword: "",
            UserRole: "",
            Email: "",
            FNameError: "",
            LNameError: "",
            PasswordError: "",
            ConfirmPasswordError: "",
            EmailError: "",
            validation: false,
            RoleId: "",
            disabled: false,
            open: false,
            message: "",
            severity: ""
        }
    }

    delay = ms => new Promise(
        resolve => setTimeout(resolve, ms)
    );

    Validate = () => {
        // ========================= Validation for FirstName
        if (this.state.FirstName === "") {
            this.setState({ FNameError: "This field cannot be empty", validation: false });
        }
        else {
            this.setState({ FNameError: "", validation: true });
        }

        // ========================= Validation for LastName
        if (this.state.LastName === "") {
            this.setState({ LNameError: "This field cannot be empty", validation: false });
        }
        else {
            this.setState({ LNameError: "", validation: true });
        }

        // ========================= Validation for Password
        const regExp = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%])[a-zA-Z0-9!@#$%^&*?]{8,}$/
        if (this.state.Password === "") {
            this.setState({ PasswordError: "This field cannot be empty", validation: false });
        }
        else if (regExp.test(this.state.Password)) {
            this.setState({ PasswordError: "", validation: true });
        }
        else if (!regExp.test(this.state.Password)) {
            this.setState({ PasswordError: "Password must contain an Uppercase letter, Lowercase letter, number, special symbol, and must be of atleast 8 characters", validation: false });
        }
        else {
            this.setState({ PasswordError: "", validation: true });
        }

        // ========================= Validation for ConfirmPassword
        if (this.state.ConfirmPassword === "") {
            this.setState({ ConfirmPasswordError: "This field cannot be empty" });
        }
        else if (this.state.ConfirmPassword !== this.state.Password) {
            this.setState({ ConfirmPasswordError: "Password does not match", validation: false });
        }
        else if (this.state.ConfirmPassword === this.state.Password) {
            this.setState({ ConfirmPasswordError: "", validation: true });
        }
        else {
            this.setState({ ConfirmPasswordError: "", validation: false });
        }

        // ========================= Validation for Email
        const regExpEmail = /^[a-zA-Z0-9._]+@[a-z]+\.[a-z]{2,6}$/
        if (this.state.Email === "") {
            this.setState({ EmailError: "This field cannot be empty", validation: false });
        }
        else if (!regExpEmail.test(this.state.Email)) {
            this.setState({ EmailError: "Email Entered Is Invalid", validation: false });
        }
        else if (regExpEmail.test(this.state.Email)) {
            this.setState({ EmailError: "", validation: true });
        }
        else {
            this.setState({ EmailError: "", validation: false });
        }
    }

    //===================== Set The Field On Change In Values
    setField = (event) => {
        this.setState({ [event.target.name]: event.target.value }, () => { this.Validate() });
    }

    //===================== Set The Check Field On Change
    setCheckField = (event) => {
        this.setState({ [event.target.name]: event.target.checked });
    }

    getRoles = async () => {
        await axios.get('/user/roles')
            .then(res => {
                if (res.status) {
                    console.log(res);
                    this.setState({ UserRoleList: res.data.data })
                }
            }, [])
            .catch(error => {
                console.log(error.response);
                console.log(error);
                // alert(error.response.status + " " + error.response.data.message);
                this.setState({ message: error.response.data.message, severity: "error", open: true }, async () => {
                    await this.delay(3000);
                    sessionStorage.clear();
                    this.props.navigate('/');
                })
            })
    }

    createUser = async () => {
        if (this.state.UserId) {
            this.updateUser();
        }
        else {
            if (this.state.validation) {
                var data = {
                    FirstName: this.state.FirstName,
                    LastName: this.state.LastName,
                    Password: this.state.Password,
                    Email: this.state.Email,
                    check: this.state.check,
                    RoleId: this.state.UserRole
                }
                console.log(data);
                axios.post('/user/create', data, { withCredentials: true })
                    .then(response => {
                        debugger;
                        console.log(response);
                        if (response.data.status) {
                            this.setState({ message: response.data.message, severity: "success", open: true }, () => {
                                this.props.navigate('/Users');
                            })
                        }
                    })
                    .catch(error => {
                        debugger
                        this.setState({ message: error.response.data.message, severity: "error", open: true }, async () => {
                            await this.delay(3000);
                            this.props.navigate('/Users');
                        })
                        // this.props.navigate('/');
                    })
            }
        }

    }

    updateUser = () => {
        debugger;
        var data = {
            UserId: this.state.UserId,
            FirstName: this.state.FirstName,
            LastName: this.state.LastName,
            IsActive: this.state.check,
            Email: this.state.Email,
            RoleId: this.state.UserRole,
        }
        axios.post('/updateUser', data, { withCredentials: true })
            .then(response => {
                if (response.data.status) {
                    this.setState({ message: response.data.message, severity: "success", open: true },async () => {
                        await this.delay(3000);
                        this.props.navigate('/Users');
                    })
                }
            })
            .catch(error => {
                // alert(error.status + " " + error.response.data.message);
                this.setState({ message: error.response.data.message, severity: "error", open: true }, async () => {
                    await this.delay(3000);
                    this.props.navigate('/Users');
                })
            })
    }

    getUserById = async () => {
        await axios.get(`/users/getUser/${this.state.UserId}`)
            .then(response => {
                console.log(response)
                if (response.data.status) {
                    this.setState({
                        FirstName: response.data.data.FirstName,
                        LastName: response.data.data.LastName,
                        Password: "********",
                        ConfirmPassword: "********",
                        Email: response.data.data.Email,
                        UserRole: response.data.data.RoleId,
                        disabled: true,
                        check: response.data.data.IsActive
                    })
                }
            })
            .catch(error => {
                console.log(error.response);
                console.log(error);
                // alert(error.response.status + error.response.message);
                this.setState({ message: error.response.data.message, severity: "error", open: true }, async () => {
                    await this.delay(3000);
                    this.props.navigate('/Users');
                })
            })
    }
    handleClose = () => {
        this.setState({ open: false });
    }
    //======================== Start Page
    render() {
        const { UserRoleList } = this.state;
        return (
            <>
                <Navbar></Navbar>
                <Stack spacing={2} sx={{ width: '100%' }}>
                    <Snackbar
                        anchorOrigin={{ vertical: "top", horizontal: "center" }}
                        open={this.state.open} autoHideDuration={3000} onClose={this.handleClose}>
                        <Alert severity={this.state.severity} sx={{ width: '100%' }} onClose={this.handleClose}>
                            {this.state.message}
                        </Alert>
                    </Snackbar>
                </Stack>
                <Grid container spacing={2} item sm={12}
                    sx={{
                        display: 'flex',
                        flexWrap: 'wrap',
                        marginX: "auto",
                        marginY: "100px",
                        fontFamily: "Times New Roman",
                        paddingTop: "20px",
                        width: "40%",
                        minWidth: "300px"
                    }
                    }>

                    <Grid container>

                        <Card
                            variant='outlined'
                            sx={{
                                width: "100%",
                                marginY: "1%",
                                marginX: "auto",
                                borderRadius: "20px",
                                padding: "2%",
                                height: "auto"
                            }}>

                            <CardContent>
                                {/*=============== Title ============ */}
                                <Grid>
                                    <Typography
                                        variant='h4'
                                        sx={{
                                            marginX: "8%",
                                            marginY: "auto",
                                            fontWeight: "bold",
                                            color: "black"
                                        }}>
                                        {this.props.title}
                                        <hr />
                                    </Typography>
                                </Grid>

                                {/*=============== TextField for FirstName and LastName ============ */}
                                <Grid sx={{ marginTop: "5%" }}>
                                    <TextField required
                                        error={this.state.FNameError && this.state.FNameError.length ? true : false}
                                        sx={{
                                            float: "center",
                                            width: "49%",
                                            // minWidth: "11rem"
                                        }}
                                        id="FirstName"
                                        name='FirstName'
                                        label="First Name"
                                        variant="filled"
                                        value={this.state.FirstName}
                                        onChange={(event) => this.setField(event)}
                                        helperText={this.state.FNameError}
                                    />
                                    <TextField required
                                        error={this.state.LNameError && this.state.LNameError.length ? true : false}
                                        sx={{
                                            float: "right",
                                            width: "49%",
                                        }}
                                        id="LastName"
                                        name='LastName'
                                        label="Last Name"
                                        variant="filled"
                                        value={this.state.LastName}
                                        onChange={(event) => this.setField(event)}
                                        helperText={this.state.LNameError}
                                    />
                                </Grid>

                                {/*============== TextField for Password and ConfirmPassword ============ */}
                                <Grid sx={{ marginTop: "5%" }}>
                                    <TextField required disabled={this.state.disabled}
                                        error={!this.state.disabled && this.state.PasswordError && this.state.PasswordError.length ? true : false}
                                        sx={{
                                            float: "center",
                                            width: "49%"
                                        }}
                                        id="Password"
                                        name='Password'
                                        label="Password"
                                        variant="filled"
                                        value={this.state.Password}
                                        onChange={(event) => this.setField(event)}
                                        type='password'
                                        helperText={!this.state.disabled ? this.state.PasswordError : ""}
                                    />
                                    <TextField required disabled={this.state.disabled}
                                        error={!this.state.disabled && this.state.ConfirmPasswordError && this.state.ConfirmPasswordError.length ? true : false}
                                        sx={{
                                            float: "right",
                                            width: "49%",
                                        }}
                                        id="ConfirmPassword"
                                        name='ConfirmPassword'
                                        label="Confirm Password"
                                        variant="filled"
                                        value={this.state.ConfirmPassword}
                                        onChange={(event) => this.setField(event)}
                                        type='password'
                                        helperText={!this.state.disabled ? this.state.ConfirmPasswordError : ""}
                                    />
                                </Grid>

                                {/*=============== TextField for Email and Roles dropdown ============ */}
                                <Grid sx={{ marginTop: "5%" }}>
                                    <TextField required
                                        error={this.state.EmailError && this.state.EmailError.length ? true : false}
                                        sx={{
                                            float: "left",
                                            width: "48%",
                                        }}
                                        id="Email"
                                        name='Email'
                                        label="Email Id"
                                        variant="filled"
                                        value={this.state.Email}
                                        onChange={(event) => this.setField(event)}
                                        helperText={this.state.EmailError}
                                    />

                                    <FormControl variant='filled'
                                        error={this.state.UserRole === "" ? true : false}
                                        sx={{ width: "48%", marginLeft: "10px" }}
                                    >
                                        <InputLabel id="UserRole">User Role</InputLabel>
                                        {
                                            <Select required
                                                labelId="UserRole"
                                                id="UserRole"
                                                name='UserRole'
                                                value={this.state.UserRole}
                                                label="UserRole"
                                                onChange={(event) => this.setField(event)}
                                            >
                                                <MenuItem value=""><em>None</em></MenuItem>
                                                {UserRoleList && UserRoleList.map((row) => {
                                                    return (
                                                        <MenuItem key={row._id} value={row._id}>{row.Role}</MenuItem>
                                                    )
                                                })};
                                            </Select>
                                        }
                                        <FormHelperText>Select A User Role</FormHelperText>
                                    </FormControl>
                                </Grid>

                                {/*=============== Status ============ */}
                                <Grid sx={{ marginTop: "7%", border: "1px solid #E0E0E0", paddingY: "2px", paddingLeft: "5px" }}>
                                    <Typography variant='span' sx={{ fontSize: "20px", fontWeight: "bold", color: "#58606e" }}>Status</Typography>
                                    <Checkbox checked={this.state.check} id='check' name='check' onChange={(event) => this.setCheckField(event)} />
                                </Grid>
                            </CardContent>
                        </Card>

                        {/*=============== Buttons ============ */}
                        <Grid sx={{ marginLeft: "auto", marginRight: "20px" }}>
                            <Button variant="contained" onClick={this.createUser} sx={{ margin: "10px" }}>Save User</Button>
                            <Link to='/Users'><Button variant="contained" sx={{ margin: "10px" }}>Cancel</Button></Link>
                        </Grid>
                    </Grid>
                </Grid >
            </>
        )
    }
}
export default withRouter(AddBook);