import React, { Component } from 'react'
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import { styled } from '@mui/material/styles';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import axios from 'axios';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import withRouter from '../withRouter';
import TablePagination from '@mui/material/TablePagination';
import Grid from '@mui/material/Grid';
import { TextField } from '@mui/material';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import setHeaderToken from './Token';
import Navbar from './Navbar';
import { Stack, Snackbar, Alert } from '@mui/material';
const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
        backgroundColor: theme.palette.common.black,
        color: theme.palette.common.white,
    },
    [`&.${tableCellClasses.body}`]: {
        fontSize: 14,
    },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
    '&:nth-of-type(odd)': {
        backgroundColor: theme.palette.action.hover,
    },
    // hide last border
    '&:last-child td, &:last-child th': {
        border: 0,
    },
}));


//============================ Class BookList
class BookList extends Component {

    componentDidMount() {
        setHeaderToken();
        this.getCategoryList();
        this.getPublisherList();
        this.getBooks();
    }

    //=================== Constructor
    constructor(props) {
        super(props);
        this.state = {
            list: [],
            BookId: "",
            BookName: "",
            CategoryName: [],
            PublisherName: [],
            PublisherId: "",
            CategoryId: "",
            modalOpen: false,
            pageCount: 0,
            pageNumber: 0,
            pageSize: 3,
            check: "All",
            isActive: "",
            BookNameToDelete: "",
            open: false,
            severity: "error",
            message: ""
        }
        this.sendBookId = this.sendBookId.bind(this);
    };

    //==================== Get The List Of Books
    getBooks = () => {
        var data = {
            BookName: this.state.BookName,
            CategoryName: this.state.CategoryName,
            PublisherName: this.state.PublisherName,
            check: this.state.check === "All" ? "" : this.state.check === "false" ? false : true
        }
        axios.post('/display', data, { withCredentials: true })
            .then(response => {
                this.setState({ list: [] });
                this.setState({ pageCount: response.data.data.length });
                this.setState({ list: response.data.data });
            }, [])
            .catch(error => {
                console.log(error.response);
                console.log(error);
                this.setState({ message: error.response.data.message, severity: "error", open: true }, async () => {
                    await this.delay(3000);
                    sessionStorage.clear();
                    this.props.navigate('/');
                });
            })
    };

    delay = ms => new Promise(
        resolve => setTimeout(resolve, ms)
    );

    //======================= Delete The Book
    DeleteBook = async () => {
        await axios.get(`/delete/${this.state.BookId}`, { withCredentials: true })
            .then(response => {
                console.log(response);
                if (response.data.status === true) {
                    this.setState({ message: "Book Deleted Successfully", severity: "success", open: true });
                }
                this.handleModalClose();
                this.getBooks();
            })
            .catch(error => {
                console.log(error.response);
                console.log(error);
                this.setState({ message: error.response.data.message, severity: "error", open: true }, async () => {
                    await this.delay(3000);
                    this.props.navigate('/Books');
                });
            })
    };
    handleOpen = (id, BookName) => {
        this.setState({ BookId: id })
        this.setState({ BookNameToDelete: BookName });
        this.setState({ modalOpen: true });
    }

    handleModalClose = () => {
        this.setState({ modalOpen: false });
    }
    sendBookId = (id) => {
        // const {history} = this.props;
        this.props.navigate(`/AddBook/${id}`);
    }

    pageChange = (event, newPage) => {
        console.log("OnPageNumberChange : ", event)
        console.log("NewPageVariable : ", newPage);
        this.setState({ pageNumber: newPage })
    }

    pageSizeChange = (event) => {
        console.log("OnPageSizeChange : ", event);
        this.setState({ pageNumber: 0, pageSize: event.target.value });
    }

    setField = (event) => {
        this.setState({ [event.target.name]: event.target.value });
    }

    getCategoryList = async () => {

        await axios.get('/category/display')
            .then(response => {
                console.log(response.data.data);
                this.setState({ categoryList: response.data.data });
            }, [])
            .catch(error => {
                console.log(error);
                this.setState({ message: error.response.data.message, severity: "error", open: true }, async () => {
                    await this.delay(3000);
                    sessionStorage.clear();
                    this.props.navigate('/');
                });
            })
    }

    // ========================== Get The List Of Publishers
    getPublisherList = async () => {

        await axios.get('/publisher/display')
            .then(response => {
                console.log(response.data.data);
                this.setState({ publisherList: response.data.data });
            }, [])
            .catch(error => {
                console.log(error.response);
                this.setState({ message: error.response.data.message, severity: "error", open: true }, async () => {
                    await this.delay(3000);
                    sessionStorage.clear();
                    this.props.navigate('/');
                });
            })
    }

    clearSearchBooks = () => {
        this.setState({ BookName: "", CategoryName: [], PublisherName: [], check: "All", pageNumber: 0 }, () => {
            this.getBooks();
        });
    }

    AddBook = async () => {
        await axios.get('/AddBook')
            .then(response => {
                debugger
                console.log("response in add book is ", response);
                if (response.status === 200) {
                    this.props.navigate('/AddBook');
                }
            })
            .catch(error => {
                console.log(error);
                this.setState({ message: error.response.data.message, severity: "error", open: true })
            })
    }
    handleClose = () => {
        this.setState({ open: false });
    }
    //============================== Start Page
    render() {
        const { categoryList } = this.state, { list } = this.state, { publisherList } = this.state;
        return (
            <>
                <Navbar></Navbar>
                <Stack spacing={2} sx={{ width: '100%' }}>
                    <Snackbar
                        anchorOrigin={{ vertical: "top", horizontal: "center" }}
                        open={this.state.open} autoHideDuration={3000} onClose={this.handleClose}>
                        <Alert severity={this.state.severity} sx={{ width: '100%' }} onClose={this.handleClose}>
                            {this.state.message}
                        </Alert>
                    </Snackbar>
                </Stack>
                {/* ============ Dialog ============== */}
                <Dialog
                    open={this.state.modalOpen}
                    onClose={() => this.handleModalClose()}
                    aria-labelledby="alert-dialog-title"
                    aria-describedby="alert-dialog-description"
                >
                    <DialogTitle id="alert-dialog-title" sx={{ fontWeight: "bold" }}>
                        {"Delete Book"}
                        <hr />
                    </DialogTitle>
                    <DialogContent>
                        <DialogContentText id="alert-dialog-description" sx={{ fontWeight: "bolder", color: "black" }}>
                            Book Name: {this.state.BookNameToDelete}
                        </DialogContentText>
                        <DialogContentText id="alert-dialog-description" sx={{ fontWeight: "bolder", color: "black" }}>
                            Are you sure you want to delete the Book?
                        </DialogContentText>
                    </DialogContent>
                    <DialogActions>
                        <Button variant='contained' color='error' onClick={() => this.DeleteBook()}>Confirm</Button>
                        <Button variant='contained' color='primary' onClick={() => this.handleModalClose()} autoFocus>
                            Close
                        </Button>
                    </DialogActions>
                </Dialog>
                {/* ============ Dialog ============== */}

                <Grid container sx={{ width: "80%", marginY: "100px", marginX: "auto", textAlign: "center" }}>
                    <Grid sx={{ width: "100%" }}>
                        <Typography variant='h4' sx={{ marginY: "1%", fontWeight: "bold", color: "white" }}>Books List</Typography>
                    </Grid>
                    <Grid item sm={12}>
                        <TextField
                            sx={{
                                float: "center",
                                width: "auto",
                                marginY: "2%",
                                backgroundColor: "white"
                            }}
                            id="BookName"
                            name='BookName'
                            label="Book Name"
                            variant="filled"
                            value={this.state.BookName}
                            onChange={(event) => this.setField(event)}
                        />

                        <FormControl variant='filled' sx={{ minWidth: "220px", width: "20%", marginLeft: "1%", marginY: "2%", backgroundColor: "white" }}>
                            <InputLabel id="CategoryName">Categories</InputLabel>
                            {this.state.categoryList &&
                                <Select multiple
                                    labelId="CategoryName"
                                    id="CategoryName"
                                    name='CategoryName'
                                    value={this.state.CategoryName}
                                    label="CategoryName"
                                    onChange={(event) => this.setField(event)}
                                >
                                    {categoryList && categoryList.map((row) => {
                                        return (
                                            <MenuItem key={row._id} value={row._id}>{row.CategoryName}</MenuItem>
                                        )
                                    })};
                                </Select>
                            }
                        </FormControl>

                        <FormControl variant='filled' sx={{ minWidth: "220px", width: "20%", marginLeft: "1%", marginY: "2%", backgroundColor: "white" }}>
                            <InputLabel id="Publishers">Publishers</InputLabel>
                            {this.state.publisherList &&
                                <Select multiple
                                    labelId="Publishers"
                                    id="PublisherName"
                                    name='PublisherName'
                                    value={this.state.PublisherName}
                                    label="Publisher"
                                    onChange={(event) => this.setField(event)}
                                >
                                    {publisherList && publisherList.map((row) => {
                                        return (
                                            <MenuItem key={row._id} value={row._id}>{row.PublisherName}</MenuItem>
                                        )
                                    })};
                                </Select>
                            }
                        </FormControl>

                        <FormControl variant='filled' sx={{ minWidth: "220px", width: "20%", marginLeft: "1%", marginY: "2%", backgroundColor: "white" }}>
                            <InputLabel id="check">Status</InputLabel>
                            {
                                <Select required
                                    labelId="check"
                                    id="check"
                                    name='check'
                                    value={this.state.check}
                                    label="check"
                                    onChange={(event) => this.setField(event)}
                                >
                                    <MenuItem value="All" defaultChecked>All</MenuItem>
                                    <MenuItem value='true'>Active</MenuItem>
                                    <MenuItem value='false'>Inactive</MenuItem>
                                </Select>
                            }
                        </FormControl>
                    </Grid>

                    <Grid item sm={12} sx={{ width: "100%" }}>
                        <Button color='primary' onClick={() => this.getBooks()} variant="contained" sx={{ margin: "10px" }}>Search Book</Button>
                        <Button color='primary' onClick={() => this.clearSearchBooks()} variant="contained" sx={{ margin: "10px" }}>Clear</Button>
                        <Button onClick={this.AddBook} color='primary' variant="contained" sx={{ margin: "10px", float: "right" }}>Add Book</Button>

                    </Grid>
                    <Grid item xs={12} sx={{ marginY: "1%" }}>
                        <Card variant='outlined' sx={{ width: "100%" }}>
                            <CardContent>

                                <TableContainer component={Paper} sx={{ justifyContent: 'center' }}>
                                    <Table aria-label="simple table">
                                        <TableHead>
                                            <StyledTableRow>
                                                <StyledTableCell sx={{ textAlign: 'center', fontWeight: "bold" }}>Book Name</StyledTableCell>
                                                <StyledTableCell sx={{ textAlign: 'center', fontWeight: "bold" }}>Category Name</StyledTableCell>
                                                <StyledTableCell sx={{ textAlign: 'center', fontWeight: "bold" }}>Active Status</StyledTableCell>
                                                <StyledTableCell sx={{ textAlign: 'center', fontWeight: "bold" }}>Publisher Name</StyledTableCell>
                                                <StyledTableCell sx={{ textAlign: 'center', fontWeight: "bold" }}>Edit</StyledTableCell>
                                                <StyledTableCell sx={{ textAlign: 'center', fontWeight: "bold" }}>Delete</StyledTableCell>
                                            </StyledTableRow>
                                        </TableHead>
                                        <TableBody>
                                            {list.slice(this.state.pageNumber * this.state.pageSize, (this.state.pageNumber * this.state.pageSize) + this.state.pageSize).map((row) => {
                                                return (
                                                    <StyledTableRow key={row._id}>
                                                        <StyledTableCell sx={{fontFamily: 'cursive'}}>{row.BookName}</StyledTableCell>
                                                        <StyledTableCell sx={{fontFamily: 'cursive'}}>{row.CategoryId.CategoryName}</StyledTableCell>
                                                        <StyledTableCell sx={{fontFamily: 'cursive'}}>{row.IsActive ? "Active" : "Inactive"}</StyledTableCell>
                                                        <StyledTableCell sx={{fontFamily: 'cursive'}}>{row.PublisherId.PublisherName}</StyledTableCell>
                                                        <StyledTableCell sx={{fontFamily: 'cursive'}}>
                                                            <Button onClick={() => this.sendBookId(row._id)} >
                                                                <EditIcon fontSize='small'></EditIcon>
                                                            </Button>
                                                            {/* <Button >   */}
                                                            {/* <Link to={`/AddBook/${row._id}`}><EditIcon fontSize='small'></EditIcon></Link> */}
                                                            {/* </Button> */}
                                                        </StyledTableCell>
                                                        <StyledTableCell>
                                                            <Button onClick={() => this.handleOpen(row._id, row.BookName)}>
                                                                <DeleteIcon fontSize='small'></DeleteIcon>
                                                            </Button>
                                                        </StyledTableCell>
                                                    </StyledTableRow>
                                                )
                                            })}
                                        </TableBody>
                                    </Table>
                                    <TablePagination
                                        rowsPerPageOptions={[3, 5, 10]}
                                        page={this.state.pageNumber}
                                        count={this.state.pageCount}
                                        rowsPerPage={this.state.pageSize}
                                        component="Grid"
                                        onPageChange={(event, newPage) => this.pageChange(event, newPage)}
                                        onRowsPerPageChange={(event) => this.pageSizeChange(event)}>
                                    </TablePagination>
                                </TableContainer>
                            </CardContent>
                        </Card>
                    </Grid>
                </Grid>
            </>
        )
    }
}
export default withRouter(BookList);