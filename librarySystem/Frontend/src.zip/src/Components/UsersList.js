import React, { Component } from 'react'
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import { styled } from '@mui/material/styles';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import axios from 'axios';
import withRouter from '../withRouter';
import TablePagination from '@mui/material/TablePagination';
import Grid from '@mui/material/Grid';
import EditIcon from '@mui/icons-material/Edit';
import setHeaderToken from './Token';
import Navbar from './Navbar';
import { Stack, Snackbar, Alert } from '@mui/material';
const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
        backgroundColor: theme.palette.common.black,
        color: theme.palette.common.white,
    },
    [`&.${tableCellClasses.body}`]: {
        fontSize: 14,
    },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
    '&:nth-of-type(odd)': {
        backgroundColor: theme.palette.action.hover,
    },
    // hide last border
    '&:last-child td, &:last-child th': {
        border: 0,
    },
}));


//============================ Class BookList
class BookList extends Component {

    componentDidMount() {
        setHeaderToken();
        this.getUserList();
    }

    //=================== Constructor
    constructor(props) {
        super(props);
        this.state = {
            pageNumber: 0,
            pageSize: 3,
            pageCount: 0,
            message: "",
            open: false,
            severity: ""
        }
    };

    delay = ms => new Promise(
        resolve => setTimeout(resolve, ms)
    );

    pageChange = (event, newPage) => {
        console.log("OnPageNumberChange : ", event)
        console.log("NewPageVariable : ", newPage);
        this.setState({ pageNumber: newPage })
    }

    pageSizeChange = (event) => {
        console.log("OnPageSizeChange : ", event);
        this.setState({ pageNumber: 0, pageSize: event.target.value });
    }

    setField = (event) => {
        this.setState({ [event.target.name]: event.target.value });
    }

    getUserList = async () => {
        await axios.get('/users/Display')
            .then(response => {
                debugger;
                console.log(response.data.data);
                this.setState({ userList: [] });
                this.setState({ pageCount: response.data.data.length });
                this.setState({ userList: response.data.data });
            }, [])
            .catch(error => {
                console.log(error.response);
                console.log(error);
                // alert(error);
                this.setState({ message: error.response.data.message, severity: "error", open: true }, async () => {
                    await this.delay(3000);
                    sessionStorage.clear();
                    this.props.navigate('/');
                })
            })
    }

    AddUser = () => {
        this.props.navigate('/AddUser');
    }

    sendUserId = (rowId) => {
        this.props.navigate(`/AddUser/${rowId}`);
    }
    //============================== Start Page
    render() {
        const { userList } = this.state;
        return (
            <>
                <Navbar></Navbar>
                <Stack spacing={2} sx={{ width: '100%' }}>
                    <Snackbar
                        anchorOrigin={{ vertical: "top", horizontal: "center" }}
                        open={this.state.open} autoHideDuration={3000} onClose={this.handleClose}>
                        <Alert severity={this.state.severity} sx={{ width: '100%' }} onClose={this.handleClose}>
                            {this.state.message}
                        </Alert>
                    </Snackbar>
                </Stack>
                <Grid container sx={{ width: "80%", marginY: "100px", marginX: "auto", textAlign: "center" }}>
                    <Grid sx={{ width: "100%" }}>
                        <Typography variant='h4' sx={{ marginY: "1%", fontWeight: "bold", color: "white" }}>Users List</Typography>
                    </Grid>

                    <Grid sx={{ width: "100%", marginY: "2%" }}>
                        <Button onClick={this.AddUser} sx={{ float: "right" }} variant='contained'>Add User</Button>
                    </Grid>
                    {/* <Grid item sm={12}>
                        <TextField
                            sx={{
                                float: "center",
                                width: "auto",
                                marginY: "2%",
                                backgroundColor: "white"
                            }}
                            id="BookName"
                            name='BookName'
                            label="Book Name"
                            variant="filled"
                            value={this.state.BookName}
                            onChange={(event) => this.setField(event)}
                        />

                        <FormControl variant='filled' sx={{ minWidth: "220px", width: "20%", marginLeft: "1%", marginY: "2%", backgroundColor: "white"}}>
                            <InputLabel id="CategoryName">Categories</InputLabel>
                            {this.state.categoryList &&
                                <Select multiple
                                    labelId="CategoryName"
                                    id="CategoryName"
                                    name='CategoryName'
                                    value={this.state.CategoryName}
                                    label="CategoryName"
                                    onChange={(event) => this.setField(event)}
                                >
                                    {categoryList && categoryList.map((row) => {
                                        return (
                                            <MenuItem key={row._id} value={row._id}>{row.CategoryName}</MenuItem>
                                        )
                                    })};
                                </Select>
                            }
                        </FormControl>

                        <FormControl variant='filled' sx={{ minWidth: "220px", width: "20%", marginLeft: "1%", marginY: "2%", backgroundColor: "white"}}>
                            <InputLabel id="Publishers">Publishers</InputLabel>
                            {this.state.publisherList &&
                                <Select multiple
                                    labelId="Publishers"
                                    id="PublisherName"
                                    name='PublisherName'
                                    value={this.state.PublisherName}
                                    label="Publisher"
                                    onChange={(event) => this.setField(event)}
                                >
                                    {publisherList && publisherList.map((row) => {
                                        return (
                                            <MenuItem key={row._id} value={row._id}>{row.PublisherName}</MenuItem>
                                        )
                                    })};
                                </Select>
                            }
                        </FormControl>

                        <FormControl variant='filled' sx={{ minWidth: "220px", width: "20%", marginLeft: "1%", marginY: "2%", backgroundColor: "white"}}>
                            <InputLabel id="check">Status</InputLabel>
                            {
                                <Select required
                                    labelId="check"
                                    id="check"
                                    name='check'
                                    value={this.state.check}
                                    label="check"
                                    onChange={(event) => this.setField(event)}
                                >
                                    <MenuItem value="All" defaultChecked>All</MenuItem>
                                    <MenuItem value='true'>Active</MenuItem>
                                    <MenuItem value='false'>Inactive</MenuItem>
                                </Select>
                            }
                        </FormControl>
                    </Grid> */}

                    {/* <Grid item sm={12} sx={{width: "100%"}}>
                        <Button color='primary' onClick={() => this.getBooks()} variant="contained" sx={{ margin: "10px" }}>Search Book</Button>
                        <Button color='primary' onClick={() => this.clearSearchBooks()} variant="contained" sx={{ margin: "10px" }}>Clear</Button>
                        <Link to='/AddBook'><Button color='primary' variant="contained" sx={{ margin: "10px", float:"right" }}>Add Book</Button></Link>
                    </Grid> */}

                    <Grid item xs={12} sx={{ marginY: "1%" }}>
                        <Card variant='outlined' sx={{ width: "100%" }}>
                            <CardContent>
                                <TableContainer component={Paper} sx={{ justifyContent: 'center' }}>
                                    <Table aria-label="simple table">
                                        <TableHead>
                                            <StyledTableRow>
                                                <StyledTableCell sx={{ textAlign: 'center', fontWeight: "bold" }}>First Name</StyledTableCell>
                                                <StyledTableCell sx={{ textAlign: 'center', fontWeight: "bold" }}>Last Name</StyledTableCell>
                                                <StyledTableCell sx={{ textAlign: 'center', fontWeight: "bold" }}>Email</StyledTableCell>
                                                <StyledTableCell sx={{ textAlign: 'center', fontWeight: "bold" }}>Role</StyledTableCell>
                                                <StyledTableCell sx={{ textAlign: 'center', fontWeight: "bold" }}>Status</StyledTableCell>
                                                <StyledTableCell sx={{ textAlign: 'center', fontWeight: "bold" }}>Actions</StyledTableCell>
                                            </StyledTableRow>
                                        </TableHead>
                                        <TableBody>
                                            {userList && userList.slice(this.state.pageNumber * this.state.pageSize, (this.state.pageNumber * this.state.pageSize) + this.state.pageSize).map((row) => {
                                                return (
                                                    <StyledTableRow key={row._id}>
                                                        <StyledTableCell sx={{ textAlign: "center",fontFamily: 'cursive' }}>{row.FirstName}</StyledTableCell>
                                                        <StyledTableCell sx={{ textAlign: "center",fontFamily: 'cursive' }}>{row.LastName}</StyledTableCell>
                                                        <StyledTableCell sx={{ textAlign: "center",fontFamily: 'cursive' }}>{row.Email}</StyledTableCell>
                                                        <StyledTableCell sx={{ textAlign: "center",fontFamily: 'cursive' }}>{row.RoleId.Role}</StyledTableCell>
                                                        <StyledTableCell sx={{ textAlign: "center",fontFamily: 'cursive' }}>{row.IsActive ? "Active" : "Inactive"}</StyledTableCell>
                                                        <StyledTableCell sx={{ textAlign: "center",fontFamily: 'cursive' }}><Button onClick={() => this.sendUserId(row._id)} >
                                                            <EditIcon fontSize='small'></EditIcon>
                                                        </Button></StyledTableCell>
                                                    </StyledTableRow>
                                                )
                                            })}
                                        </TableBody>
                                    </Table>
                                    <TablePagination
                                        rowsPerPageOptions={[3, 5, 10]}
                                        page={this.state.pageNumber}
                                        count={this.state.pageCount}
                                        rowsPerPage={this.state.pageSize}
                                        component="Grid"
                                        onPageChange={(event, newPage) => this.pageChange(event, newPage)}
                                        onRowsPerPageChange={(event) => this.pageSizeChange(event)}>
                                    </TablePagination>
                                </TableContainer>
                            </CardContent>
                        </Card>
                    </Grid>
                </Grid>
            </>
        )
    }
}
export default withRouter(BookList);