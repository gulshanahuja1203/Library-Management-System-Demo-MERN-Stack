import React, { Component } from 'react'
import { AppBar, Toolbar, Typography } from '@mui/material'
import Button from '@mui/material/Button';
import axios from 'axios';
import withRouter from '../withRouter';
import setHeaderToken from './Token';
import Snackbar from '@mui/material/Snackbar';
import { Stack } from '@mui/material';
import { Alert } from '@mui/material';
import { Grid } from '@mui/material'
class Navbar extends Component {

    constructor() {
        super();
        this.state = {
            message: "",
            open: false,
            severity: ""
        }
    }

    delay = ms => new Promise(
        resolve => setTimeout(resolve, ms)
    )
    logout = () => {
        sessionStorage.clear();
        setHeaderToken();
        this.props.navigate('/');
    }

    redirectToBooks = () => {
        setHeaderToken();
        axios.get('/Books')
            .then(response => {
                if (response.status === 200) {
                    this.props.navigate('/Books')
                }
                else {
                    alert(response.status + response.data.message);
                }
            })
            .catch(error => {
                console.log("error response is In Navbar ", error.response.data.message);
                this.setState({ message: error.response.data.message, severity: "error", open: true }, async () => {
                    await this.delay(3000);
                    sessionStorage.clear();
                    this.props.navigate('/');
                });
            })
    }

    redirectToUsers = () => {
        setHeaderToken();
        axios.get('/Users')
            .then(response => {
                if (response.status === 200) {
                    this.props.navigate('/Users')
                }
                else {
                    alert(response.status + response.data);
                }
            })
            .catch(error => {
                console.log("error response is  ", error.response.data.message);
                this.setState({ message: error.response.data.message, severity: "error", open: true }, async () => {
                    await this.delay(3000);
                    sessionStorage.clear();
                    this.props.navigate('/');
                });

            })
    }
    handleClose = () => {
        this.setState({ open: false });
    }
    render() {
        return (
            <>
                <Grid>
                    <Stack spacing={2} sx={{ width: '100%' }}>
                        <Snackbar
                        anchorOrigin={{ vertical: "top", horizontal: "center" }} 
                        open={this.state.open} autoHideDuration={3000} onClose={this.handleClose}>
                            <Alert severity={this.state.severity} sx={{ width: '100%' }} onClose={this.handleClose}>
                                {this.state.message}
                            </Alert>
                        </Snackbar>
                    </Stack>

                    <AppBar color='secondary' sx={{ position: "fixed", zIndex: "3" }}>
                        <Toolbar>
                            <Typography sx={{ fontWeight: "bolder" }}>Library Management System</Typography>

                            <Button onClick={this.redirectToBooks} sx={{ color: "white" }}>Books</Button>

                            <Button onClick={this.redirectToUsers} sx={{ color: "white" }}>Users</Button>

                            <Button onClick={this.logout} sx={{ color: "white" }}>Logout</Button>
                        </Toolbar>
                    </AppBar>
                </Grid>
            </>
        )
    }
}
export default withRouter(Navbar);