const dbconfig = require("../config/db.config");

const mongoose = require("mongoose");
mongoose.Promise = global.Promise;

const db = {};
db.mongoose = mongoose;
db.url = dbconfig.url;
db.books = require("./book.model.js")(mongoose);
db.categories = require("./category.model.js")(mongoose);
db.publishers = require("./publisher.model.js")(mongoose);
db.roles = require("./role.model")(mongoose);
module.exports = db;