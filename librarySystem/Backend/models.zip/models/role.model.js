const mongoose = require("mongoose");
const secretKey = "RhealSoftware2023";

const { Schema } = mongoose;
const Role = new mongoose.Schema(
    {
        Role: {
            type: String
        }
    }
);

module.exports = mongoose.model("role", Role);