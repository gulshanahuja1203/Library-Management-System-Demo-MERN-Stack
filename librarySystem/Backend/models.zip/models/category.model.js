const mongoose = require("mongoose");
const secretKey = "RhealSoftware2023";

const { Schema } = mongoose;
const Category = new mongoose.Schema(
    {
        CategoryName:
        {
            type: String,
        }
    }
);

module.exports = mongoose.model("category", Category);