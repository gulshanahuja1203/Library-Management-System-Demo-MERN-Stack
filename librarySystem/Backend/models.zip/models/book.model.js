const mongoose = require("mongoose");
const secretKey = "RhealSoftware2023";

const { Schema } = mongoose;
const Book = new mongoose.Schema(
    {
        BookName: {
            type: String,
          //  required: true
        },
        IsActive: { type: Boolean, default: false },
        CategoryId: {type: mongoose.Schema.Types.ObjectId, ref: 'category'},
        PublisherId: {type: mongoose.Schema.Types.ObjectId, ref: 'publisher'},
    }
);

module.exports = mongoose.model("book", Book);