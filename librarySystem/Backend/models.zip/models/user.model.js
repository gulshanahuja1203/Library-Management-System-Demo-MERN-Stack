const mongoose = require("mongoose");
const secretKey = "RhealSoftware2023";

const { Schema } = mongoose;
const User = new mongoose.Schema(
    {
        FirstName: {
            type: String,
          //  required: true
        },
        LastName: {
            type: String,
          //  required: true
        },
        Password: {
            type: String
        },
        Email: {
            type: String
        },
        RoleId: {
            type: mongoose.Schema.Types.ObjectId, ref: 'role'
        },
        IsActive: {
            type: Boolean, default: false
        }
    }
);

module.exports = mongoose.model("user", User);