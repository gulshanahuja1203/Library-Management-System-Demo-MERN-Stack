const mongoose = require("mongoose");
const secretKey = "RhealSoftware2023";

const { Schema } = mongoose;
const Publisher = new mongoose.Schema(
    {
        PublisherName:
        {
            type: String,
        }
    }
);

module.exports = mongoose.model("publisher", Publisher);