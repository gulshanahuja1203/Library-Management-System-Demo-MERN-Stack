const Role = require('../models/role.model')
const index = require('./index');
const isAuthenticated = require('../auth/isAuthenticated')
module.exports = (app) => {
    app.get('/user/roles',isAuthenticated, async (req, res) => {
        console.log("In Roles");
        const getRoles = await Role.find();
        if(getRoles){
            res.send({status: true, message: "Roles fetched successfully", data: getRoles});
        }
        else{
            res.send({status: false, message: "Something went wrong"});
        }
    });
    return app;
}