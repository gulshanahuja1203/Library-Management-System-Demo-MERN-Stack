const { json } = require('body-parser');
const Publisher = require("../models/publisher.model");
const isAuthenticated = require('../auth/isAuthenticated');
module.exports = (app) => {
    app.get('/publisher/display',isAuthenticated, async (req, res) => {
        const publisherList = await Publisher.find();
        res.send({status: true, message: "successful", data: publisherList});
    }
    )

    app.get('/getPublisher/:id',isAuthenticated, async(req, res) => {
        console.log("In Get Publisher Function");
        const getPublisher = await Publisher.findOne({_id: req.params.id});
        if(getPublisher){
            res.send({status: true, message: "Book search successful", data: getPublisher});
        }
        else{
            res.send({status: false, message: "something went wrong"});
        }
      });
    return app;
};