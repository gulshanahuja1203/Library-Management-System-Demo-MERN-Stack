const User = require('../models/user.model');
const bcrypt = require('bcryptjs');
const salt = bcrypt.genSalt(10);
const jwt = require('jsonwebtoken');
const secretKey = "RhealSoftware2023";
const isAuthenticated = require('../auth/isAuthenticated')
const isAdmin = require('../auth/isAdmin')
module.exports = (app) => {
    app.post('/user/create', isAuthenticated, isAdmin, async (req, res) => {
        console.log("In User Create");
        const findUser = await User.findOne({ Email: req.body.Email })
        if (findUser) {
            res.send({ status: false, message: "User Already Exists" });
        }
        else {
            const inUser = new User();
            inUser.FirstName = req.body.FirstName,
                inUser.LastName = req.body.LastName,
                inUser.Email = req.body.Email,
                inUser.Password = bcrypt.hashSync(req.body.Password, 10),
                inUser.IsActive = req.body.check,
                inUser.RoleId = req.body.RoleId
            await inUser.save();
            if (inUser) {
                res.send({ status: true, message: "User Created Successfully" })
            }
            else {
                res.send({ status: false, message: "Something went wrong" });
            }
        }
    });

    app.get('/users/Display', isAuthenticated, async (req, res) => {
        console.log("In Display Users");

        let getUsers = await User.find().populate({ path: "RoleId" })
        if (getUsers) {
            res.send({ status: true, message: "fetched users list successfully", data: getUsers });
        }
        else {
            res.send({ status: false, message: "Something went wrong" });
        }
    });

    app.get('/users/getUser/:id', isAuthenticated, async (req, res) => {
        console.log("In get User");
        const getUser = await User.findOne({ _id: req.params.id }).select('-Password');
        if (getUser) {
            res.send({ status: true, message: "User Found", data: getUser });
        }
        else {
            res.send({ status: false, message: "Could not fetch the user" });
        }
    });

    app.post('/updateUser', isAuthenticated, isAdmin, async (req, res) => {
        console.log("In Users Update")
        console.log(req.body);
        const findUser = await User.findOne({_id: req.body.UserId});
        if(findUser){
            findUser.FirstName = req.body.FirstName;
            findUser.LastName = req.body.LastName,
            findUser.IsActive = req.body.IsActive,
            findUser.Email = req.body.Email,
            findUser.RoleId = req.body.RoleId
            findUser.save();
            res.send({status: true, message: "User Updated Successfully, Redirecting to List"})
        }
        else{
            res.send({status: false, message: "No User Found"});
        }
    })
    app.post('/loginUser', async (req, res) => {
        console.log("Login req ", req.body);
        let findUser = await User.findOne({ Email: req.body.Email });
        if (findUser) {
            if (bcrypt.compareSync(req.body.Password, findUser.Password)) {
                const userEmail = {
                    user: findUser.Email
                }
                const token = jwt.sign(userEmail, secretKey, { expiresIn: "2h" })
                res.send({ status: true, message: "SignIn Successfull", token });
            }
            else {
                res.send({ status: false, message: "Please login using correct credentials" });
            }
        }
        else {
            res.send({ status: false, message: "Please login using correct credentials" });
        }
    });

    app.get('/Users', isAuthenticated, async (req, res) => {
        res.status(200).send({ message: "Successfully Decoded" });
    })

    return app;
}