const Book = require('../models/book.model');
const index = require('./index');
const isAuthenticated = require('../auth/isAuthenticated');
const isAdmin = require('../auth/isAdmin');
module.exports = (app) => {

    //To Insert A Book If It Does Not Exists
    app.post('/create', isAuthenticated, async (req, res) => {
        console.log(req.session);
        console.log("in saveBook function");
        try {

            console.log('in books save');
            const foundBook = await Book.findOne({ BookName: req.body.BookName })
            if (foundBook) {
                res.send({ status: true, message: 'This book already exists' });
            } else {
                const newBook = new Book();

                newBook.BookName = req.body.BookName;
                newBook.IsActive = req.body.check;
                newBook.CategoryId = req.body.CategoryId;
                newBook.PublisherId = req.body.PublisherId
                await newBook.save()
                res.send({ status: true, message: 'New Book successfully created', Book: newBook });
            }
        }
        catch (error) {
            res.send({ status: false, message: error.message, Book: [] });
        }
    })

    app.post('/display',isAuthenticated, async (req, res) => {
        console.log("In BooksList");
        // console.log("In BooksList authorization is", req.headers.authorization.split(" ")[1]);
        const searchCriteria = {};
        if (req.body.BookName && req.body.BookName !== "") {
            const regexForBook = new RegExp(`.*${req.body.BookName}.*`, 'i');
            searchCriteria.BookName = regexForBook;
        }
        if (req.body.CategoryName && req.body.CategoryName.length > 0) {
            searchCriteria.CategoryId = { $in: req.body.CategoryName };
        }
        if (req.body.PublisherName && req.body.PublisherName.length > 0) {
            searchCriteria.PublisherId = { $in: req.body.PublisherName }
        }
        if (req.body.check !== "") {
            searchCriteria.IsActive = req.body.check;
        }
        let BookFind = await Book.find(searchCriteria).populate([{ path: "CategoryId" }, { path: "PublisherId" }]);
        if (BookFind) {
            res.send({ status: true, message: "successful", data: BookFind });
        }
        else {
            res.send({ status: false, message: "Failure" });
        }
    }
    )

    app.get('/delete/:id', isAuthenticated, isAdmin, async (req, res) => {
        console.log("In delete:", req.params.id)
        // const foundBook = await Book.findOne({ _id: req.params.id });
        const foundBookToDelete = await Book.updateOne({ _id: req.params.id }, {
            $set: { IsActive: false }
        })

        if (foundBookToDelete.acknowledged) {
            res.send({ status: true, message: 'User successfully deleted' });
        }
        else {
            res.send({ status: false, message: "Something went wrong" });
        }
    });

    app.get('/getBook/:id', isAuthenticated, async (req, res) => {
        console.log("In Get Book Function");
        console.log("session in getbookbyid ", res.session);
        const getBook = await Book.findOne({ _id: req.params.id });
        if (getBook) {
            res.send({ status: true, message: "Book search successful", data: getBook });
        }
        else {
            res.send({ status: false, message: "something went wrong" });
        }
    });

    app.get('/Books', isAuthenticated,  async (req, res) => {
        res.status(200).send({message: "Successfully Decoded"});
    })

    app.get('/AddBook', isAuthenticated,  async (req, res) => {
        console.log("In AddBook")
        res.status(200).send({message: "Successfully Decoded"});
    })
    
    app.post('/updateBook', isAuthenticated, isAdmin, async (req, res) => {
        console.log("In Update Book : ");

        const getBookToUpdate = await Book.updateOne({ _id: req.body.BookId },
            {
                $set: {
                    BookName: req.body.BookName,
                    IsActive: req.body.check,
                    CategoryId: req.body.CategoryId,
                    PublisherId: req.body.PublisherId
                }
            })

        if (getBookToUpdate.acknowledged) {
            res.send({ status: true, message: "Book Update Successfull" });
        }
        else {
            res.send({ status: false, message: "Something went wrong" });
        }
    });
    return app;
};