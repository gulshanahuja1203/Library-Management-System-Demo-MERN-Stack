const { json } = require('body-parser');
const Category = require('../models/category.model');
const isAuthenticated = require('../auth/isAuthenticated');
module.exports = (app) => {
    app.get('/category/display', isAuthenticated, async (req, res) => {
        const categoryList = await Category.find();
        res.send({status: true, message: "successful", data: categoryList});
    });

    app.get('/getCategory/:id', isAuthenticated, async(req, res) => {
        console.log("In Get Book Function");
        const getCategory = await Category.findOne({_id: req.params.id});
        if(getCategory){
            res.send({status: true, message: "Book search successful", data: getCategory});
        }
        else{
            res.send({status: false, message: "something went wrong"});
        }
      });

    return app;
};