module.exports = (app) => {
  require('./book.routes')(app);
  require('./category.routes')(app);
  require('./publisher.route')(app);
  require('./role.routes')(app);
  require('./user.routes')(app);
  // == Models
  require('../models/book.model');
  require('../models/category.model');
  require('../models/publisher.model');
  require('../models/role.model');
  require('../models/user.model');
  return app;
};