const secretKey = "RhealSoftware2023";
const jwt = require('jsonwebtoken');

const User = require('../models/user.model')
const isAdmin= (req, res, next) => {
    console.log("In isAdmin")
    jwt.verify(req.headers.authorization.split(" ")[1], secretKey, async (error, decoded) => {
        if (error) {
            console.log("You are trying to hack me");
        }
        else {
            console.log("Decoded Token ", decoded);
            const userData = await User.findOne({Email: decoded.user}).populate({path: "RoleId"}).select("-Password");
            console.log(userData);
            if(userData){
                userData.RoleId.Role === "Admin"? next() : res.status(401).send({message: "You are not an Admin, Please contact Admin to perform Insert/Update/Delete Operation"});
            }
        }
    });
}
module.exports = isAdmin;