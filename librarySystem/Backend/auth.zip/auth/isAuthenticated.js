const jwt = require('jsonwebtoken');
const secretKey = "RhealSoftware2023";
const isAuthenticated = (req, res, next) => {
    console.log("In IsAuthenticated");
    console.log(req.headers.authorization);
    if (req.headers.authorization && req.headers.authorization.split(" ")[1] !== "undefined") {
        jwt.verify(req.headers.authorization.split(" ")[1], secretKey, (error, decoded) => {
            if (error) {
                console.log("You are trying to hack me");
                res.status(401).send({message: "You modified the token, Unauthorised, Redirecting you to Login"});
            }
            else {
                console.log("Decoded Token ", decoded);
                next();
            }
        });
    }
    else {
        res.status(401).send({ message: "You are Unauthorised, Please try again after Login" });
    }
}

module.exports = isAuthenticated;